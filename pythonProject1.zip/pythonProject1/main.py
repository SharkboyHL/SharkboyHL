from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def homepage():
    return render_template('index.html')


@app.route('/second')
def secondpage():
    return '<h1>Você chegou na segunda página !</h1>'


@app.route('/pessoas/<string:nome>/<string:cidade>')
def pessoas(nome, cidade):
    return 'Nome: {}, Cidade: {}'.format(nome, cidade)


if __name__ == '__main__':
    app.run(debug=True)
