package Pessoa;

public class Professor extends Pessoa{
    public String siape;
}
