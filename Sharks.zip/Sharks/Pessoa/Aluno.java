package Pessoa;

public class Aluno extends Pessoa {
    public String matricula;
    public Aluno() {
        System.out.println("Fugazza casa comigo <3");
    }
}