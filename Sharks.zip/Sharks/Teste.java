import Pessoa.Aluno;
import Pessoa.Professor;

public class Teste {
    public static void main(String[] args) {
        Aluno aluno1 = new Aluno();
        Professor professor1 = new Professor();

        aluno1.nome = "Fugazza";
        aluno1.idade = 16;
        aluno1.matricula = "202010101";

        System.out.println("nome: " + aluno1.nome);
        System.out.println("idade: " + aluno1.idade);
        System.out.println("matricula: " + aluno1.matricula);

        professor1.nome = "Varela";
        professor1.idade = 98;
        professor1.siape = "202002020";

        System.out.println("nome: " + professor1.nome);
        System.out.println("idade: " + professor1.idade);
        System.out.println("siape: " + professor1.siape);
    }
}